#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "map.h"
#include "chessSystem.h"
#include "chessTournament.h"
#include "chessMapUtils.h"

#define WIN_GAME_SCORE 2
#define DRAW_GAME_SCORE 1
#define BAD_INPUT (-999)

struct chess_tournament_t{
    int tournament_id;
    int max_games_per_player;
    char* tournament_location;
    PlayerID tournament_winner_player_id;
    Map tournament_games;
    Map tournament_players;
};

/**
* buildPlayersRankMap: Calculates rank of all tournament's active players, and returns a map where
*                      the keys are the players' IDs, and the data is the associated player's rank
*                      as follows: player_rank = (num_of_wins*2 + num_of_draws*1) / (num_of_games_of_player)
                                                 *
 * @param tournament
 * @return Map of player_id : total_rank
 */
static Map buildPlayersRankMap(ChessTournament tournament);

/**
 * findWinnerPlayerID: Finds the winner player_id and writes it to the attribute
 *                      `winner_player_id`.
 *                      Called by endTournament as a part of general actions to end game.
 *
 * @param tournament - The tournament to of which players are to be ranked. Must be non-NULL.
 * @return
 *      NULL if tournament is NULL
 *      A Map of the tournament players' ranks.
 */
static ChessResult findWinnerPlayerID(ChessTournament tournament);

/**
 * addPlayer: Add a player into Map of players of a tournament.
 * @param tournament Tournament to add players into.
 * @param player ChessPlayer to be added
 * @return
 *      CHESS_SUCCESS if addition succeeded, or other ChessResult if an error occurred.
 *      Errors: CHESS_OUT_OF_MEMORY, CHESS_NULL_ARGUMENT.
 */
static ChessResult addPlayer(ChessTournament tournament, ChessPlayer player);

ChessTournament tournamentCreate(int tournament_id, int max_games_per_player, const char* tournament_location){
    if(tournament_id <= 0 || max_games_per_player <= 0) {
        return NULL;
    }
    ChessTournament result = malloc(sizeof (*result));
    if(!result){
        return NULL;
    }
    result->tournament_location = malloc(strlen(tournament_location)+1);
    if(!tournament_location){
        free(result->tournament_location);
        tournamentDestroy(result);
        return NULL;
    }
    Map tournament_games = mapCreate(gamesMapCopyData, stringCopyFunc, gamesMapFreeData,
                                     mapFreeStringKey, mapCompareStringKeys);
    if(!tournament_games){
        free(result->tournament_location);
        tournamentDestroy(result);
        return NULL;
    }
    Map tournament_players = mapCreate(playersMapCopyData, playersMapCopyKey,
                                       playersMapFreeData, playersMapFreeKey, playersMapComp);
    if(!tournament_players){
        free(result->tournament_location);
        mapDestroy(tournament_games);
        tournamentDestroy(result);
        return NULL;
    }
    result->tournament_id = tournament_id;
    result->tournament_winner_player_id = NULL;
    result->max_games_per_player = max_games_per_player;
    strcpy(result->tournament_location, tournament_location);
    result->tournament_games = tournament_games;
    result->tournament_players = tournament_players;
    return result;
}

ChessTournament tournamentCopy(ChessTournament src_tournament){
    if(!src_tournament){
        return NULL;
    }
    ChessTournament dst_tournament = malloc(sizeof (*dst_tournament));
    if (!dst_tournament) {
        return NULL;
    }

    dst_tournament->tournament_location = malloc(strlen(src_tournament->tournament_location) + 1);
    if(!dst_tournament->tournament_location){
        tournamentDestroy(dst_tournament);
        return NULL;
    }
    PlayerID dst_tournament_winner_player_id;
    if(src_tournament->tournament_winner_player_id == NULL){
        dst_tournament_winner_player_id = NULL;
    }
    else{
        dst_tournament_winner_player_id = playerIDCopy(src_tournament->tournament_winner_player_id);
        if(!dst_tournament_winner_player_id){
            free(dst_tournament->tournament_location);
            free(dst_tournament);
            return NULL;
        }
    }

    Map tournament_games = mapCopy(src_tournament->tournament_games);
    if(!tournament_games){
        free(dst_tournament->tournament_location);
        playerIDDestroy(dst_tournament_winner_player_id);
        free(dst_tournament);
        return NULL;
    }
    Map tournament_players = mapCopy(src_tournament->tournament_players);
    if(!tournament_players){
        free(dst_tournament->tournament_location);
        playerIDDestroy(dst_tournament_winner_player_id);
        mapDestroy(tournament_games);
        free(dst_tournament);
        return NULL;
    }
    dst_tournament->tournament_id = src_tournament->tournament_id;
    dst_tournament->max_games_per_player = src_tournament->max_games_per_player;
    strcpy(dst_tournament->tournament_location, src_tournament->tournament_location);
    dst_tournament->tournament_winner_player_id = dst_tournament_winner_player_id;
    dst_tournament->tournament_games = tournament_games;
    dst_tournament->tournament_players = tournament_players;
    return dst_tournament;
}

void tournamentDestroy(ChessTournament tournament){
    if(!tournament){
        return;
    }
    if(tournament->tournament_location) {
        free(tournament->tournament_location);
    }
    if(tournament->tournament_winner_player_id){
        playerIDDestroy(tournament->tournament_winner_player_id);
    }
    if(tournament->tournament_games){
        mapDestroy(tournament->tournament_games);
    }
    if(tournament->tournament_players) {
        mapDestroy(tournament->tournament_players);
    }
    free(tournament);
}

Map tournamentGetGames(ChessTournament tournament){
    if(!tournament){
        return NULL;
    }
    if(!tournament->tournament_games){
        return NULL;
    }
    return tournament->tournament_games;
}

Map tournamentGetPlayers(ChessTournament tournament){
    if (!tournament){
        return NULL;
    }
    return tournament->tournament_players;
}

char* tournamentGetTournamentLocation(ChessTournament tournament){
    if(!tournament){
        return NULL;
    }
    return tournament->tournament_location;
}

bool tournamentIsOver(ChessTournament tournament){
    if(!tournament){
        return true;
    }
    return tournament->tournament_winner_player_id != NULL;
}

ChessResult tournamentAddGame(ChessTournament tournament, ChessGame game){
    if(!tournament || !game){
        return CHESS_NULL_ARGUMENT;
    }
    if (tournamentIsOver(tournament)){
        return CHESS_TOURNAMENT_ENDED;
    }
    char* game_id = gameGetID(game);
    if(!game_id){
        return CHESS_NULL_ARGUMENT;
    }
    if (mapGet(tournament->tournament_games, game_id)){
        return CHESS_GAME_ALREADY_EXISTS;
    }
    MapResult result = mapPut(tournament->tournament_games, game_id, game);
    if(result == MAP_OUT_OF_MEMORY){
        mapRemove(tournament->tournament_games, game_id);
        return CHESS_OUT_OF_MEMORY;
    }
    // Game is inserted to tournament->games
    // Insert players from game into tournament->players
    bool player1_is_new = false;
    bool player2_is_new = false;
    PlayerID player1_id = gameGetPlayer1ID(game);
    ChessPlayer player1 = mapGet(tournament->tournament_players, player1_id);
    if (!player1){
        player1_is_new = true;
        player1 = playerCreate(player1_id);
        ChessResult chess_result = addPlayer(tournament, player1);
        if(chess_result != CHESS_SUCCESS){
            mapRemove(tournament->tournament_games, game_id);
            playerIDDestroy(player1_id);
            playerDestroy(player1);
            return chess_result;
        }
        playerDestroy(player1);
        player1 = NULL;
    }
    PlayerID player2_id = gameGetPlayer2ID(game);
    ChessPlayer player2 = mapGet(tournament->tournament_players, player2_id);
    if (!player2){
        player2_is_new = true;
        player2 = playerCreate(player2_id);
        ChessResult chess_result = addPlayer(tournament, player2);
        if(chess_result != CHESS_SUCCESS){
            mapRemove(tournament->tournament_games, game_id);
            playerIDDestroy(player2_id);
            playerDestroy(player2);
            if(player1_is_new){
                mapRemove(tournament->tournament_players,player1_id);
            }
            return chess_result;
        }
        playerDestroy(player2);
        player2 = NULL;
    }
    player1 = mapGet(tournament->tournament_players, player1_id);
    player2 = mapGet(tournament->tournament_players, player2_id);
    int player1_num_of_games = playerGetNumOfGames(player1);
    int player2_num_of_games = playerGetNumOfGames(player2);
    if(player1_num_of_games == tournament->max_games_per_player ||
        player2_num_of_games == tournament->max_games_per_player){
            mapRemove(tournament->tournament_games, game_id);
            return CHESS_EXCEEDED_GAMES;
    }
    ChessResult res = playerAddGame(player1, game);
    if(res != CHESS_SUCCESS)
    {
        mapRemove(tournament->tournament_games, game_id);
        playerRemoveGame(player1, game);
        if(player1_is_new){
            mapRemove(tournament->tournament_players,player1_id);
        }
        if(player2_is_new){
            mapRemove(tournament->tournament_players,player2_id);
        }
        return (ChessResult)res;
    }
    res = playerAddGame(player2, game);
    if (res != CHESS_SUCCESS){
        mapRemove(tournament->tournament_games, game_id);
        if(player1_is_new){
            mapRemove(tournament->tournament_players,player1_id);
        }
        if(player2_is_new){
            mapRemove(tournament->tournament_players,player2_id);
        }
        playerRemoveGame(player1, game);
        return (ChessResult) res;
    }
    if ((!player1_is_new && playerGetNumOfGames(player1) > tournament->max_games_per_player) ||
            (!player2_is_new && playerGetNumOfGames(player2) > tournament->max_games_per_player)){
        mapRemove(tournament->tournament_games, game_id);
        if(player1_is_new){
            mapRemove(tournament->tournament_players,player1_id);
        }
        if(player2_is_new){
            mapRemove(tournament->tournament_players,player2_id);
        }
        playerRemoveGame(player1, game);
        playerRemoveGame(player2, game);
        return CHESS_EXCEEDED_GAMES;
    }

    return CHESS_SUCCESS;
}

ChessResult tournamentEndTournament(ChessTournament tournament) {
    if(!tournament){
        return CHESS_NULL_ARGUMENT;
    }
    if(mapGetSize(tournament->tournament_games) == 0){
        return CHESS_NO_GAMES;
    }
    ChessResult res = findWinnerPlayerID(tournament);
    return res;
}

//ChessResult tournamentRemovePlayer(ChessTournament tournament, PlayerID player_id){
//    if(!tournament || !player_id){
//        return CHESS_NULL_ARGUMENT;
//    }
//    ChessPlayer player = mapGet(tournament->tournament_players, player_id);
//    if(!player){
//        return CHESS_PLAYER_NOT_EXIST;
//    }
//    // For every game that player is taking part of set rival to be the winner.
//    MAP_FOREACH(char*, game_id, tournament->tournament_games){
//        ChessGame game = mapGet(tournament->tournament_games, game_id);
//        if (playerIDCompare(gameGetPlayer1ID(game), player_id)){
//            gameSetWinner(game,SECOND_PLAYER);
//        }
//        if (playerIDCompare(gameGetPlayer2ID(game), player_id)){
//            gameSetWinner(game,FIRST_PLAYER);
//        }
//        free(game_id);
//    }
//    playerSetIsDeleted(player);
//    return CHESS_SUCCESS;
//}

PlayerID tournamentGetWinnerPlayerID(ChessTournament tournament){
    if(!tournament){
        return NULL;
    }
    return tournament->tournament_winner_player_id;
}

int tournamentGetLongestGameTime(ChessTournament tournament){
    if(!tournament){
        return BAD_INPUT;
    }
    Map games = tournament->tournament_games;
    int max_time = BAD_INPUT;
    MAP_FOREACH(char*, iter, games){
        ChessGame current_game = mapGet(games, iter);
        int current_play_time = gameGetPlayTime(current_game);
        if(current_play_time>max_time){
            max_time = current_play_time;
        }
        free(iter);
    }
    return max_time;
}

double tournamentGetAverageGameTime(ChessTournament tournament){
    if(!tournament){
        return (double)BAD_INPUT;
    }
    Map games = tournament->tournament_games;
    if(mapGetSize(games) == 0){
        return 0;
    }
    int all_time = 0;
    MAP_FOREACH(char*, iter, games){
        ChessGame current_game = mapGet(games, iter);
        int current_play_time = gameGetPlayTime(current_game);
        all_time+=current_play_time;
        free(iter);
    }
    int all_games = mapGetSize(games);
    return (double)all_time/(double)all_games;
}

int tournamentGetNumOfGames(ChessTournament tournament){
    if(!tournament){
        return BAD_INPUT;
    }
    return mapGetSize(tournament->tournament_games);
}

int tournamentGetNumOfAllPlayers(ChessTournament tournament){
    if(!tournament){
        return BAD_INPUT;
    }
    return mapGetSize(tournament->tournament_players);
}

bool tournamentLocationIsValid(const char* tournament_name){
    if(!tournament_name){
        return false;
    }
    if (!isupper(tournament_name[0])){
        return false;
    }
    for (int i = 1; i < strlen(tournament_name) ;i++){
        if (!(isspace(tournament_name[i]) || islower(tournament_name[i]))){
            return false;
        }
    }
    return true;
}

static Map buildPlayersRankMap(ChessTournament tournament){
    if(!tournament){
        return NULL;
    }
    Map active_players = mapCopy(tournamentGetPlayers(tournament));
    if (!active_players) {
        return NULL;
    }
    MAP_FOREACH(PlayerID, player_id, tournament->tournament_players){
        ChessPlayer current_player = mapGet(tournament->tournament_players, player_id);
        if(playerIsDeleted(current_player)){
            mapRemove(active_players, player_id);
        }
        playerIDDestroy(player_id);
    }
    Map players_rank = mapCreate(intCopyFunc, playersMapCopyKey, intFreeFunc, playersMapFreeKey, playersMapComp);
    if(!players_rank){
        mapDestroy(active_players);
        return NULL;
    }
    int init_rank = 0;
    MAP_FOREACH(PlayerID, player_id, active_players){
        mapPut(players_rank, player_id, &init_rank);
        playerIDDestroy(player_id);
    }
    mapDestroy(active_players);
    // Calculate Rank FOREACH Player
    MAP_FOREACH(char*, current_game_id, tournament->tournament_games) {
        ChessGame current_game = mapGet(tournament->tournament_games, current_game_id);
        PlayerID player1_id = gameGetPlayer1ID(current_game);
        PlayerID player2_id = gameGetPlayer2ID(current_game);
        int *player1_rank_ptr = NULL, *player2_rank_ptr = NULL;
        if (mapContains(players_rank, player1_id)) {
            player1_rank_ptr = (int *) mapGet(players_rank, player1_id);
        }
        if (mapContains(players_rank, player2_id)) {
            player2_rank_ptr = (int *) mapGet(players_rank, player2_id);
        }
        if (gameGetWinner(current_game) == FIRST_PLAYER) {
            if (player1_rank_ptr) {
                (*player1_rank_ptr) += WIN_GAME_SCORE;
            }
        }
        if (gameGetWinner(current_game) == SECOND_PLAYER) {
            if (player2_rank_ptr) {
                (*player2_rank_ptr) += WIN_GAME_SCORE;
            }
        }
        if (gameGetWinner(current_game) == DRAW) {
            if (player1_rank_ptr) {
                (*player1_rank_ptr) += DRAW_GAME_SCORE;
            }
            if (player2_rank_ptr) {
                (*player2_rank_ptr) += DRAW_GAME_SCORE;
            }
        }
        free(current_game_id);
    }
    return players_rank;
}

static ChessResult findWinnerPlayerID(ChessTournament tournament){
    Map players_rank = buildPlayersRankMap(tournament);
    if(!players_rank){
        return CHESS_OUT_OF_MEMORY;
    }
    // Find max rank
    int max_rank=0;
    MAP_FOREACH(PlayerID ,player_id, players_rank){
        int current_player_rank = *(int*)(mapGet(players_rank, player_id));
        if(current_player_rank > max_rank){
            max_rank = current_player_rank;
        }
        playerIDDestroy(player_id);
    }
    // Find all players with rank max_rank
    Map players_have_max_rank = mapCopy(players_rank);
    if(!players_have_max_rank){
        mapDestroy(players_rank);
        return CHESS_OUT_OF_MEMORY;
    }
    MAP_FOREACH(PlayerID, player_id, players_rank){
        int current_player_rank = *(int*)(mapGet(players_rank, player_id));
        if(current_player_rank < max_rank){
            mapRemove(players_have_max_rank, player_id);
        }
        playerIDDestroy(player_id);
    }
    mapDestroy(players_rank);
    // In a case of a single player has max rank
    if(mapGetSize(players_have_max_rank) == 1){
        tournament->tournament_winner_player_id = (PlayerID)mapGetFirst(players_have_max_rank);;
        mapDestroy(players_have_max_rank);
        return CHESS_SUCCESS;
    }
    // Else, there are multiple players with max score. Continue calculating min_losses among players have max score
    // Find minimal loser
    PlayerID first_id_in_list = (PlayerID)mapGetFirst(players_have_max_rank);
    if(!first_id_in_list){
        mapDestroy(players_have_max_rank);
        return CHESS_OUT_OF_MEMORY;
    }
    ChessPlayer first_player = mapGet(tournament->tournament_players, first_id_in_list);
    int min_losing_games = playerGetNumOfLosses(first_player);
    playerIDDestroy(first_id_in_list);
    MAP_FOREACH(PlayerID, player_id, players_have_max_rank){
        ChessPlayer current_player = mapGet(tournament->tournament_players, player_id);
        int num_of_games_lost = playerGetNumOfLosses(current_player);
        if(num_of_games_lost<min_losing_games){
            min_losing_games = num_of_games_lost;
        }
        playerIDDestroy(player_id);
    }
    Map minimal_losers = mapCopy(players_have_max_rank);
    if(!minimal_losers){
        mapDestroy(players_have_max_rank);
        return CHESS_OUT_OF_MEMORY;
    }
    MAP_FOREACH(PlayerID, player_id, players_have_max_rank) {
        ChessPlayer current_player = mapGet(tournament->tournament_players, player_id);
        if(playerGetNumOfLosses(current_player)>min_losing_games){
            mapRemove(minimal_losers, player_id);
        }
        playerIDDestroy(player_id);
    }
    mapDestroy(players_have_max_rank);
    // In a case of a single player has max rank
    if(mapGetSize(minimal_losers) == 1){
        tournament->tournament_winner_player_id = (PlayerID)mapGetFirst(minimal_losers);
        mapDestroy(minimal_losers);
        return CHESS_SUCCESS;
    }
    // Else, there are multiple players with minimum losing games. Continue calculating maximum winning games
    // Find maximal winner
    int max_winning_games = 0;
    MAP_FOREACH(PlayerID, player_id, minimal_losers){
        ChessPlayer current_player = mapGet(tournament->tournament_players, player_id);
        int player_win_games = playerGetNumOfWins(current_player);
        if(player_win_games > max_winning_games){
            max_winning_games = player_win_games;
        }
        playerIDDestroy(player_id);
    }
    // Find all players have max_win_games
    Map maximal_winners = mapCopy(minimal_losers);
    if(!maximal_winners){
        mapDestroy(minimal_losers);
        return CHESS_OUT_OF_MEMORY;
    }
    MAP_FOREACH(PlayerID, player_id, minimal_losers){
        ChessPlayer current_player = mapGet(tournament->tournament_players, player_id);
        int player_win_games = playerGetNumOfWins(current_player);
        if (player_win_games < max_winning_games){
            mapRemove(maximal_winners, player_id);
        }
        playerIDDestroy(player_id);
    }
    mapDestroy(minimal_losers);
    // If there is a single player has maximal number of winning games, it will be the mapGetFirst (map length equals one), else
    // returns the min player_id, which is the mapGetFirst either due to map default ASC sort by key.
    tournament->tournament_winner_player_id = (PlayerID)mapGetFirst(maximal_winners);
    if(!tournament->tournament_winner_player_id){
        mapDestroy(maximal_winners);
        return CHESS_OUT_OF_MEMORY;
    }
    mapDestroy(maximal_winners);
    return CHESS_SUCCESS;
}

static ChessResult addPlayer(ChessTournament tournament, ChessPlayer player){
    if(!tournament || !player){
        return CHESS_NULL_ARGUMENT;
    }
    PlayerID player_id = playerGetID(player);
    if(!player_id){
        return CHESS_NULL_ARGUMENT;
    }
    MapResult map_result = mapPut(tournament->tournament_players, player_id, player);
    if (map_result == MAP_OUT_OF_MEMORY) {
        return CHESS_OUT_OF_MEMORY;
    }
    return CHESS_SUCCESS;
}

