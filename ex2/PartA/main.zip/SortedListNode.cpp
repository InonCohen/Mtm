#include <cstdlib>
#include <cstdio>
#include <iostream>
#include "SortedListNode.h"

namespace mtm{

    template <class T>
    SortedListNode<T>::SortedListNode(T value, SortedListNode* prev, SortedListNode *next) : value(value ? value : NULL), prev(prev), next(next){}

    template <class T>
    SortedListNode<T>::SortedListNode(const SortedListNode<T> &node) : value(node.value), prev(node.prev), next(node.next){}

    template <class T>
    SortedListNode<T>* SortedListNode<T>::getPrev() const
    {
        return this->prev;
    }

    template <class T>
    SortedListNode<T>* SortedListNode<T>::getNext() const
    {
        return this->next;
    }

    template <class T>
    void SortedListNode<T>::setPrev(const SortedListNode* node)
    {
        this->prev = node;
    }

    template <class T>
    void SortedListNode<T>::setNext(const SortedListNode* node)
    {
        this->next = node;
    }

    template <class T>
    const T& SortedListNode<T>::getValue() const
    {
        return this->value;
    }


    template <class T>
    void SortedListNode<T>::setValue(T &val)
    {
        this->value = val;
    }

    template <class T>
    SortedListNode<T>& SortedListNode<T>::clone() const
    {
        SortedListNode<T> to_return;
        to_return.setValue(this->value);
        to_return.setPrev(nullptr);
        to_return.setNext(nullptr);
        return to_return;
    }

    template <class T>
    bool SortedListNode<T>::operator==(SortedListNode<T> &to_compare)
    {
        if (to_compare == NULL)
        {
            return false;
        }
        return (value == to_compare.value && next = to_compare.next && prev == to_compare.prev);
    }


template <class T>
std::ostream &operator<<(std::ostream &os, const SortedListNode<T> &to_print)
{
    os << to_print.getValue();
    return os;
}
}