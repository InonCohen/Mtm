#ifndef GENERICTWLIST_TWLIST_NODE_H
#define GENERICTWLIST_TWLIST_NODE_H

#include <cstdlib>
#include <cstdio>
#include <iostream>

namespace mtm{
    template <class T>
    class SortedListNode
    {
        T value;
        SortedListNode<T> *prev;
        SortedListNode<T> *next;

    public:
        SortedListNode() = default;
        explicit SortedListNode(T value, SortedListNode *prev = NULL, SortedListNode *next = NULL);
        explicit SortedListNode(const SortedListNode<T> &node);
        ~SortedListNode() = default;
        SortedListNode* getPrev() const;
        SortedListNode* getNext() const;
        void setPrev(const SortedListNode *node);
        void setNext(const SortedListNode *node);
        const T& getValue() const;
        void setValue(T &val);
        SortedListNode<T>& clone() const;
        bool operator==(SortedListNode<T> &to_compare);
    };

    template <class T>
    std::ostream &operator<<(std::ostream &os, const SortedListNode<T> &to_print);
}

#endif //GENERICTWLIST_TWLIST_NODE_H
