#include <string>
#include "SortedList.h"

int main(){
    mtm::SortedList<int> list1;
    list1.insert(7);
    return 0;
}
