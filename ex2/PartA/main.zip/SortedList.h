#ifndef TW_LIST_NO_ITER_HPP
#define TW_LIST_NO_ITER_HPP
#include <assert.h>
#include <string>
#include "SortedListNode.h"

//#define BIGGER '>'
//#define SMALLER '<'
//#define EQUAL '='
//#define NOT_EQUAL '!'
//#define BIG_EQUAL '#'
//#define SMALL_EQUAL '%'

namespace mtm{
    typedef enum
    {
        TW_LIST_OUT_OF_MEMORY = -2,
        TW_LIST_INVALID_INPUT = -3,
        TW_LIST_SUCCESS = 0,
        TW_LIST_FAILURE = -1
    } SortedListResult;

    template <class T>
    class SortedList
    {
    private:
        SortedListNode<T> *head;
        SortedListNode<T> *tail;
        int num_of_nodes = 0;
        int key;

    public:
        SortedList<T>();

        /**
     * //~SortedList()//:
     * - SortedList destructor.
     *
     * Template Requirements:
     * T destructor
      */
        ~SortedList();

        /**
             * //SortedList<T>(const SortedList<T> &SortedList)//:
             * - SortedList<T> copy constructor
             *
             * Template Requirements:
              * -~T() destructor
              */
        SortedList<T>(const SortedList<T> &other);



        /**
             * //SortedList<T> &operator=(const SortedList<T> &SortedList)//:
             * - SortedList<T> assignment operator
             *
             * Template Requirements:
              * - T() constructor with no parameters.
              *  T assignment operator.
              *  ~T() destructor
              */
        SortedList<T> &operator=(const SortedList<T> &twList);

        /**
             * //const int size() constt//:
             * - returns number of elements in given SortedList.
             * Template Requirements: none
              */
        const int size() const;

        SortedListNode<T> *getHead()
        {
            if (num_of_nodes == 0)
                return NULL;
            return head;
        };

        SortedListNode<T> *getTail()
        {
            if (num_of_nodes == 0)
                return NULL;
            return tail;
        };

        const int getKey() { return this->key; }
        void setKey(int new_key) { this->key = new_key; }

        SortedListResult insert(const T &to_add);

        SortedListResult remove(SortedListNode<T> *to_remove);

        SortedList<T> clone();

        SortedListNode<T> *contains(const T &element);
        SortedListNode<T> *contains(const int key);

        std::string printList();
        /** //logical operator comparison functions://
        //SortedList<bool> operator(T to_compare)//:
        - recieves paramter to compare with SortedList (T).
        - returns SortedList in which each element is the result of the logical comparison (1 if true 0 if false).
        - dimensions of SortedList are dimensions of the compared SortedList (of *this SortedList).
        - SortedList is returned by value.
        * Template Requirements:
             *  T() constructor with no parameters.
             *  T assignment operator (=).
             *  ~T(): destructor.
             * T copy constructor
             *  T operator of logical comparison (matching operator for every function):
             * (==,!=,<=,>=,<,>)
        */
        bool operator==(const SortedList<T> &twList) const;
        bool operator!=(const SortedList<T> &twList) const;
        bool operator<=(const SortedList<T> &twList) const;
        bool operator>=(const SortedList<T> &twList) const;
        bool operator<(const SortedList<T> &twList) const;
        bool operator>(const SortedList<T> &twList) const;

        void emptyList();
    };
}





#endif //PARTB_PARTB_H
